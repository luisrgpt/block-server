package pt.ulisboa.tecnico.meic.sirs;

public interface ByteArrayMixer {
    byte[] mix(byte[] byteArray1, byte[] byteArray2);
}
